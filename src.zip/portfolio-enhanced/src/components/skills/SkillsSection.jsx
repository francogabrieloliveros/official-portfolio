import { useReveal } from "../../hooks/useReveal";
import Icons from "../../assets/icons";

const languages = [
  { name: "JavaScript", icon: "javascript", level: 90 },
  { name: "Python",     icon: "python",     level: 78 },
  { name: "C",          icon: "c",          level: 70 },
  { name: "Java",       icon: "java",       level: 72 },
  { name: "R",          icon: "r",          level: 60 },
];

const frontend = [
  { name: "React",       icon: "react",    level: 88 },
  { name: "Tailwind CSS",icon: "tailwind", level: 85 },
];

const backend = [
  { name: "MongoDB",   icon: "mongo",   level: 75 },
  { name: "ExpressJS", icon: "express", level: 78 },
  { name: "NodeJS",    icon: "node",    level: 80 },
];

const marqueeItems = [
  "JavaScript", "React", "NodeJS", "Python", "Java", "C",
  "MongoDB", "ExpressJS", "Tailwind CSS", "R", "Arduino",
  "Socket.IO", "Vite", "JavaFX", "Mistral AI",
];

function SkillBar({ name, icon, level }) {
  const Icon = Icons[icon];
  return (
    <div className="reveal group flex flex-col gap-1.5">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <Icon w="18px" />
          <span className="text-[0.95rem]">{name}</span>
        </div>
        <span className="section-label">{level}%</span>
      </div>
      <div className="h-[3px] w-full bg-black/10">
        <div
          className="h-full bg-black transition-all duration-1000"
          style={{ width: `${level}%`, transitionDelay: "0.3s" }}
        />
      </div>
    </div>
  );
}

function SkillGroup({ title, items }) {
  return (
    <div className="reveal flex flex-col gap-5">
      <div className="flex items-center gap-3">
        <div className="h-px flex-1 bg-black/20" />
        <h3 className="section-label">{title}</h3>
        <div className="h-px flex-1 bg-black/20" />
      </div>
      <div className="flex flex-col gap-4">
        {items.map((item) => (
          <SkillBar key={item.name} {...item} />
        ))}
      </div>
    </div>
  );
}

function SkillsSection() {
  const sectionRef = useReveal();

  return (
    <section className="mb-24 sm:mb-32" id="skills" ref={sectionRef}>
      <p className="reveal section-label mb-3">— what i work with</p>
      <h2 className="florilst reveal mb-10 text-[2rem]">Skills</h2>

      <div className="reveal grid gap-10 sm:grid-cols-2 lg:grid-cols-3">
        <SkillGroup title="Languages"  items={languages} />
        <SkillGroup title="Front-end"  items={frontend}  />
        <SkillGroup title="Back-end"   items={backend}   />
      </div>

      {/* Marquee strip */}
      <div className="reveal mt-14 overflow-hidden border-y border-black/10 py-4">
        <div className="marquee-track select-none">
          {[...marqueeItems, ...marqueeItems].map((item, i) => (
            <span key={i} className="mr-10 text-[0.8rem] font-semibold uppercase tracking-widest opacity-30">
              {item} ✦
            </span>
          ))}
        </div>
      </div>
    </section>
  );
}

export default SkillsSection;
